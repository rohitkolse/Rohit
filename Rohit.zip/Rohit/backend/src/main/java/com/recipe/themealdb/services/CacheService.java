package com.recipe.themealdb.services;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class CacheService {

    @Cacheable(value = "apiCache", key = "#key")
    public String cacheResponse(String key, String data) {
        return data;
    }
}
