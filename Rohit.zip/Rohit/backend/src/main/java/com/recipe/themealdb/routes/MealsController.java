package com.recipe.themealdb.routes;

import com.recipe.themealdb.services.MealService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/meals")
@CrossOrigin("*")
public class MealsController {

    private final MealService service;

    public MealsController(MealService service) {
        this.service = service;
    }

    @GetMapping("/search")
    public String search(@RequestParam String q) {
        return service.search(q);
    }

    @GetMapping("/random")
    public String randomMeal() {
        return service.randomMeal();
    }

    @GetMapping("/details/{id}")
    public String details(@PathVariable String id) {
        return service.mealDetails(id);
    }

    
}
