package com.recipe.themealdb.utils;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class ApiClient {

    private final RestTemplate rest = new RestTemplate();

    public String get(String url) {
        return rest.getForObject(url, String.class);
    }
}
