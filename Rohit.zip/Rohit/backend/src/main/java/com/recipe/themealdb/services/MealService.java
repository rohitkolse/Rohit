package com.recipe.themealdb.services;

import com.recipe.themealdb.utils.ApiClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class MealService {

    @Value("${external.api}")
    private String baseUrl;

    private final ApiClient api;
    private final CacheService cache;

    public MealService(ApiClient api, CacheService cache) {
        this.api = api;
        this.cache = cache;
    }

    public String search(String query) {
        String url = baseUrl + "/search.php?s=" + query;
        String data = api.get(url);
        return cache.cacheResponse("search_" + query, data);
    }

    public String randomMeal() {
        String url = baseUrl + "/random.php";
        String data = api.get(url);
        return cache.cacheResponse("random", data);
    }

    public String categories() {
        String url = baseUrl + "/categories.php";
        String data = api.get(url);
        return cache.cacheResponse("categories", data);
    }

    public String mealDetails(String id) {
        String url = baseUrl + "/lookup.php?i=" + id;
        String data = api.get(url);
        return cache.cacheResponse("details_" + id, data);
    }
}
