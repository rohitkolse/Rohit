package com.recipe.themealdb.routes;

import com.recipe.themealdb.services.MealService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/categories")
@CrossOrigin("*")
public class CategoryController {

    private final MealService service;

    public CategoryController(MealService service) {
        this.service = service;
    }

    @GetMapping
    public String categories() {
        return service.categories();
    }
}
