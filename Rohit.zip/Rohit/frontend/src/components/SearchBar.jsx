export default function SearchBar({ value, onChange, onSearch }) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        gap: "12px",
        width: "100%",
      }}
    >
      <input
        type="text"
        value={value}
        placeholder="Search meals..."
        onChange={(e) => onChange(e.target.value)}
        style={{
          width: "350px",
          maxWidth: "85%",
          padding: "12px 15px",
          borderRadius: "8px",
          border: "1px solid #ddd",
          fontSize: "16px",
        }}
      />

      <button
        onClick={onSearch}
        style={{
          padding: "12px 22px",
          background: "#ff5722",
          color: "white",
          border: "none",
          borderRadius: "8px",
          cursor: "pointer",
          fontSize: "16px",
          fontWeight: "bold",
        }}
      >
        Search
      </button>
    </div>
  );
}
