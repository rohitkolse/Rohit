export default function MealDetails({ meal }) {
  if (!meal) return <p>Loading...</p>;

  const ingredients = [];
  for (let i = 1; i <= 20; i++) {
    const ing = meal[`strIngredient${i}`];
    const measure = meal[`strMeasure${i}`];
    if (ing) ingredients.push(`${ing} - ${measure}`);
  }

  return (
    <div className="details">
      <h1>{meal.strMeal}</h1>
      <img src={meal.strMealThumb} className="big-img" />

      <h2>Ingredients</h2>
      <ul>
        {ingredients.map((i, idx) => (
          <li key={idx}>{i}</li>
        ))}
      </ul>

      <h2>Instructions</h2>
      <p>{meal.strInstructions}</p>

      {meal.strYoutube && (
        <iframe
          width="100%"
          height="300"
          src={meal.strYoutube.replace("watch?v=", "embed/")}
        ></iframe>
      )}
    </div>
  );
}
