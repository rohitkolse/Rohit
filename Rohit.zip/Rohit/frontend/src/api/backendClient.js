import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:8080/api",
});

export default {
  search: (q) => API.get(`/meals/search?q=${q}`),
  random: () => API.get(`/meals/random`),
  details: (id) => API.get(`/meals/details/${id}`),
  categories: () => API.get(`/categories`),
};
