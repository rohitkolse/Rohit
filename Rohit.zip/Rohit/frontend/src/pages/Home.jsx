import { useState } from "react";
import SearchBar from "../components/SearchBar";
import MealCard from "../components/MealCard";
import api from "../api/backendClient";

export default function Home() {
  const [query, setQuery] = useState("");
  const [meals, setMeals] = useState([]);

  const handleSearch = async () => {
    const res = await api.search(query);
    setMeals(res.data.meals || []);
  };

  return (
    <div
      className="page"
      style={{
        minHeight: "100vh",
        width: "100%",
        backgroundImage: `url("/bg.jpg")`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        textAlign: "center",
        paddingTop: "60px",
      }}
    >

      <h1
        style={{
          fontSize: "42px",
          marginBottom: "10px",
          fontWeight: "800",
          color: "white",
          textShadow: "0px 4px 10px rgba(0,0,0,0.7)",
        }}
      >
        ROHIT'S KITCHEN
      </h1>

      <p
        style={{
          fontSize: "22px",
          color: "#ffe9b3",
          fontWeight: "600",
          marginBottom: "30px",
          textShadow: "0 2px 6px rgba(0,0,0,0.6)",
          letterSpacing: "1px",
        }}
      >
        “Taste the Magic of Every Bite!”
      </p>

      <SearchBar value={query} onChange={setQuery} onSearch={handleSearch} />

      <div
        className="grid"
        style={{
          marginTop: "40px",
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
          gap: "20px",
          width: "90%",
          maxWidth: "1200px",
        }}
      >
        
        {meals.map((m) => (
          <MealCard key={m.idMeal} meal={m} />
        ))}
      </div>
    </div>
  );
}
