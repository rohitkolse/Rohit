import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import MealDetails from "../components/MealDetails";
import api from "../api/backendClient";

export default function MealPage() {
  const { id } = useParams();
  const [meal, setMeal] = useState(null);

  useEffect(() => {
    api.details(id).then((res) => {
      setMeal(res.data.meals[0]);
    });
  }, [id]);

  return (
    <div className="page">
      <MealDetails meal={meal} />
    </div>
  );
}
