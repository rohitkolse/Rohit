import { useEffect, useState } from "react";
import CategoryList from "../components/CategoryList";
import MealCard from "../components/MealCard";
import api from "../api/backendClient";

export default function Categories() {
  const [categories, setCategories] = useState([]);
  const [meals, setMeals] = useState([]);

  useEffect(() => {
    api.categories().then((res) => {
      setCategories(res.data.categories);
    });
  }, []);

  const loadCategoryMeals = async (cat) => {
    const res = await api.search(cat);
    setMeals(res.data.meals || []);
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        width: "100%",
        backgroundImage: `url("/bg.jpg")`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
      }}
    >
      <div
        style={{
          minHeight: "100vh",
          backgroundColor: "rgba(0,0,0,0.55)",
          backdropFilter: "blur(3px)",
          padding: "50px",
          color: "white",
          textAlign: "center",
        }}
      >
      
        <h1
          style={{
            fontSize: "48px",      
            fontWeight: "900",
            marginBottom: "40px",   
            textShadow: "0px 4px 10px rgba(0,0,0,0.7)",
          }}
        >
          Categories
        </h1>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))",
            gap: "30px",                    
            justifyItems: "center",
            marginBottom: "50px",
          }}
        >
          {categories.map((cat, idx) => (
            <div
              key={idx}
              onClick={() => loadCategoryMeals(cat.strCategory)}
              style={{
                width: "220px",
                height: "220px",
                borderRadius: "18px",
                backgroundColor: "rgba(255,255,255,0.15)",
                backdropFilter: "blur(5px)",
                padding: "20px",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                cursor: "pointer",
                transition: "0.3s",
                boxShadow: "0 4px 10px rgba(0,0,0,0.4)",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = "scale(1.05)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = "scale(1)";
              }}
            >
              <img
                src={cat.strCategoryThumb}
                alt={cat.strCategory}
                style={{
                  width: "120px",
                  height: "120px",
                  borderRadius: "12px",
                  objectFit: "cover",
                  marginBottom: "15px",
                }}
              />
              <h2
                style={{
                  fontSize: "22px",
                  fontWeight: "700",
                  textShadow: "0px 2px 5px rgba(0,0,0,0.6)",
                }}
              >
                {cat.strCategory}
              </h2>
            </div>
          ))}
        </div>

        <div className="grid">
          {meals.map((m) => (
            <MealCard key={m.idMeal} meal={m} />
          ))}
        </div>
      </div>
    </div>
  );
}
